﻿using System.Collections.Generic;

namespace FelineFrenzy
{
    public class SceneManager
    {
        private readonly Stack<IScene> sceneStack; // Stack to store the active scenes

        public SceneManager()
        {
            sceneStack = new Stack<IScene>(); // Initialize the stack
        }

        // Adds a new scene to the stack and loads it
        public void AddScene(IScene scene)
        {
            scene.Load(); // Load the scene's content or setup
            sceneStack.Push(scene); // Push the scene onto the stack
        }

        // Removes the top scene from the stack
        public void RemoveScene()
        {
            sceneStack.Pop(); // Pop the top scene off the stack
        }

        // Returns the current active scene (the scene on top of the stack)
        public IScene GetCurrentScene()
        {
            return sceneStack.Peek(); // Get the current scene without removing it
        }
    }
}
