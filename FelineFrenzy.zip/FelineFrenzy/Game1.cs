﻿using FelineFrenzy;
using FelineFrenzy1.Menu; // Import necessary namespace for menu-related functionality
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FelineFrenzy1
{
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics; // Graphics device manager to handle screen settings
        private SpriteBatch _spriteBatch; // SpriteBatch for rendering sprites
        private SceneManager sceneManager; // Manages scene transitions and active scenes

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this); // Initialize graphics device manager
            Content.RootDirectory = "Content"; // Root directory for content loading
            IsMouseVisible = true; // Makes the mouse cursor visible
            sceneManager = new SceneManager(); // Initialize scene manager to handle scenes
        }

        protected override void Initialize()
        {
            _graphics.PreferredBackBufferHeight = 1080; // Set preferred back buffer height
            _graphics.PreferredBackBufferWidth = 1920; // Set preferred back buffer width
            _graphics.ApplyChanges(); // Apply the changes to the graphics settings

            base.Initialize();
        }

        protected override void LoadContent()
        {
            _spriteBatch = new SpriteBatch(GraphicsDevice); // Initialize sprite batch
            // Add the MenuScene to the scene manager, passing necessary parameters
            sceneManager.AddScene(new MenuScene(Content, sceneManager, _graphics));
        }

        protected override void Update(GameTime gameTime)
        {
            // Exit the game when Back button is pressed or Escape key is held down
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
                Exit();

            // Update the currently active scene
            sceneManager.GetCurrentScene().Update(gameTime);
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue); // Clear the screen with a blue background
            // Draw the current scene using the sprite batch
            sceneManager.GetCurrentScene().Draw(_spriteBatch);

            base.Draw(gameTime);
        }
    }
}
