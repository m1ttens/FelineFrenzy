﻿using FelineFrenzy;
using FelineFrenzy.Generics;
using FelineFrenzy.Levels;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace FelineFrenzy1.Menu
{
    // The MenuScene class represents the main menu scene of the game.
    // It manages the background, title, buttons, and mouse interactions.
    internal class MenuScene : IScene
    {
        // ContentManager to load game assets.
        private ContentManager ContentManager;

        // SceneManager to handle scene transitions.
        private SceneManager SceneManager;

        // GraphicsDeviceManager for rendering graphics.
        private GraphicsDeviceManager Graphics;

        // MouseManager to track mouse interactions.
        private MouseManager MouseManager;

        // Current and previous states of the mouse.
        MouseState currentMouseState;
        MouseState previousMouseState;

        // Position of the mouse pointer and its bounding rectangle.
        Vector2 MousePosition;
        Rectangle MouseRectangle;

        // Constructor initializes the scene with necessary managers.
        public MenuScene(ContentManager contentManager, SceneManager sceneManager, GraphicsDeviceManager graphics)
        {
            this.ContentManager = contentManager;
            this.SceneManager = sceneManager;
            this.Graphics = graphics;
        }

        // Sprites for the menu components.
        Sprite BackGround;
        Sprite TitleScreen;
        Sprite ButtonPlay;
        Sprite ButtonExit;

        // Load method initializes sprites and assets for the menu.
        public void Load()
        {
            // Load background image.
            BackGround = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/SkyBackground"), new Vector2(0, 0), Color.White, 1.0f);

            // Load title screen image.
            TitleScreen = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/Title"), new Vector2(293, 17), Color.White, 1.0f);

            // Load "Play" button.
            ButtonPlay = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/ButtonPlay"), new Vector2(706, 540), Color.White, 1.0f);

            // Load "Exit" button.
            ButtonExit = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/ButtonExit"), new Vector2(706, 771), Color.Yellow, 1.0f);

            // Initialize the MouseManager.
            MouseManager = new MouseManager();
        }

        // UpdateMouse method tracks the mouse's current position and state.
        public void UpdateMouse()
        {
            // Update the mouse state using the MouseManager.
            MouseManager.UpdateMouse();

            // Save the previous mouse state for comparison.
            previousMouseState = currentMouseState;

            // Get the current mouse state.
            currentMouseState = Mouse.GetState();

            // Update the mouse position and its bounding rectangle.
            MousePosition = new Vector2(currentMouseState.X, currentMouseState.Y);
            MouseRectangle = new Rectangle((int)currentMouseState.X, (int)currentMouseState.Y, 1, 1);
        }

        // Update method handles game logic and menu interactions.
        public void Update(GameTime gameTime)
        {
            // Update mouse state.
            UpdateMouse();

            // Check if the "Play" button is clicked.
            if (ButtonPlay.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, ButtonPlay.rect))
            {
                // Transition to the LevelMenu scene.
                SceneManager.AddScene(new LevelMenu(ContentManager, SceneManager, Graphics));
            }

            // Check if the "Exit" button is clicked.
            if (ButtonExit.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, ButtonExit.rect))
            {
                // Exit the application.
                Environment.Exit(0);
            }
        }

        // Draw method renders the menu components to the screen.
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();

            // Draw background (Layer 1).
            BackGround.Draw(spriteBatch);

            // Draw title screen (Layer 2).
            TitleScreen.Draw(spriteBatch);

            // Draw "Play" button (Layer 3).
            ButtonPlay.Draw(spriteBatch);

            // Draw "Exit" button (Layer 4).
            ButtonExit.Draw(spriteBatch);

            spriteBatch.End();
        }
    }
}
