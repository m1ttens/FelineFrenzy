﻿
using var game = new FelineFrenzy1.Game1();
game.Run();
