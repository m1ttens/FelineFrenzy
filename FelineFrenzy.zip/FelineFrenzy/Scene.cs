﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

namespace FelineFrenzy
{
    // Interface defining the core structure for game scenes
    public interface IScene
    {
        // Method to load any content or setup required for the scene
        void Load();

        // Method to update the scene logic. Called every frame to handle game logic.
        void Update(GameTime gameTime);

        // Method to draw the scene. Responsible for rendering visual elements.
        void Draw(SpriteBatch spriteBatch);
    }
}
