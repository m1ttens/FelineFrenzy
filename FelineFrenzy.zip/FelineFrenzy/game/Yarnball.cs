﻿using FelineFrenzy.Generics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Collections.Generic;

namespace FelineFrenzy.Game
{
    internal class Yarnball : Sprite
    {
        private int VelocityY; // The vertical velocity of the yarnball

        // Constructor for Yarnball
        public Yarnball(Texture2D texture, Vector2 position, Color colour, float opacity, int velocityY)
            : base(texture, position, colour, opacity) // Call the base Sprite constructor
        {
            rect = new Rectangle((int)Position.X, (int)Position.Y, 66, 63); // Initialize the bounding rectangle
            VelocityY = velocityY; // Set the vertical velocity
        }

        // Update method for Yarnball
        public void UpdateYarnBall(Player player, SceneManager sceneManager, List<Tile> Tilelist)
        {
            // Move the Yarnball vertically based on its velocity
            Position.Y += VelocityY;
            rect.Y += VelocityY;

            // Check if the Yarnball intersects with the player's bounding rectangle
            if (rect.Intersects(player.rect))
            {
                player.PlayerDeath(sceneManager); // Call PlayerDeath method if collision is detected
            }
        }
    }
}
