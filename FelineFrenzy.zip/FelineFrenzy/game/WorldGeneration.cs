﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelineFrenzy.Game
{
    internal class WorldGeneration
    {
        // 2D array to store level data from the file
        public int[,] data;

        // List to hold the tiles in the world
        private List<Tile> tiles;

        // Content manager for loading assets
        private ContentManager content;

        // Grid system for managing tiles
        private Grid grid;

        // File path to the level data file
        

        int index;
        // Constructor to initialize world generation with necessary data
        public WorldGeneration(List<Tile> Tiles, ContentManager Content, Grid Grid, int Index, string filepath)
        {
            this.index = Index;
            this.tiles = Tiles;
            this.content = Content;
            this.grid = Grid;

            // Update the world generation based on the provided data
            WorldGenerationUpdate(Tiles, Content, Grid, filepath );
        }
        
        // Method to read and process the level data file
        public void WorldGenerationUpdate(List<Tile> Tiles, ContentManager Content, Grid grid, string path)
        {
            // Path to the CSV file containing level layout

          

            string filepath = path;

            // Read all lines from the CSV file
            string[] lines = File.ReadAllLines(filepath);

            // Determine the number of rows and columns in the level data
            int rowcount = lines.Length;
            int columncount = lines[0].Split(',').Length;

            // Initialize the data array to hold the level data
            int[,] data = new int[rowcount, columncount];

            // Populate the data array by parsing the CSV lines
            for (int y = 0; y < rowcount; y++)
            {
                string[] col = lines[y].Split(',');
                for (int x = 0; x < columncount; x++)
                {
                    data[y, x] = Convert.ToInt32(col[x]);
                }
            }

            // Get the dimensions of the data array
            int rows = data.GetLength(0);
            int columns = data.GetLength(1);

            int i = 0; // Row index

            // Loop through each row in the data array
            while (i < rows)
            {
                int j = 0; // Reset column index for each new row

                // Loop through each column in the current row
                while (j < columns)
                {
                    if (data[i, j] != -1) // Skip empty tiles (represented by -1)
                    {
                        // Add a new tile at the appropriate position
                        Tiles.Add(new Tile(
                            Content.Load<Texture2D>("GameSprites/SpriteSheetTiles"),
                            new Vector2(j * 128, i * 128),  // Corrected positioning for X (column) and Y (row)
                            Color.White,
                            1.0f,
                            data[i, j] // Tile type or ID
                        ));
                    }

                    j++; // Move to the next column
                }

                i++; // Move to the next row
            }
        }
    }
}
