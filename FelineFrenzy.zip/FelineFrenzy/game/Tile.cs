﻿using FelineFrenzy.Generics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelineFrenzy.Game
{
    // The Tile class represents a specific tile in the game, inheriting from the Sprite class.
    internal class Tile : Sprite
    {
        // The index of the tile in the texture regions (used for selecting the appropriate sprite from the sprite sheet).
        public int index;

        // Constructor to initialize a tile with its texture, position, color, opacity, and index.
        // Parameters:
        // - texture: The texture atlas containing all tile sprites.
        // - position: The position of the tile on the screen.
        // - colour: The color tint to apply to the tile.
        // - opacity: The transparency level of the tile.
        // - Index: The index of the tile within the texture regions array.
        public Tile(Texture2D texture, Vector2 position, Color colour, float opacity, int Index)
            : base(texture, position, colour, opacity) // Calls the base class (Sprite) constructor.
        {
            this.index = Index; // Assign the tile's index.

            // Define the tile's rectangle with a fixed size (128x128 pixels).
            rect = new Rectangle((int)position.X, (int)Position.Y, 128, 128);
        }

        // Draws the tile on the screen.
        // Parameters:
        // - spriteBatch: The SpriteBatch used for rendering.
        // - TextureRegions: An array of rectangles defining regions of the texture atlas for each sprite.
        public void Draw(SpriteBatch spriteBatch, Rectangle[] TextureRegions)
        {
            // Draw the tile using its texture, position, the appropriate texture region, and color with opacity.
            spriteBatch.Draw(Texture, Position, TextureRegions[index], colour * opacity);
        }
    }
}

