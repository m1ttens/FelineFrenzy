﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelineFrenzy.Game
{
    // The Camera class controls the visible area of the game world relative to the player's position.
    internal class Camera
    {
        // The position of the camera in the game world.
        public Vector2 Position;

        // The smoothing speed used for gradual camera movement (not currently used in this implementation).
        private float _smoothSpeed = 0.01f;

        // The viewport representing the visible screen area.
        private readonly Viewport _viewport;

        // The bounds of the game world within which the camera is restricted.
        private Rectangle _worldBounds;

        // Constructor to initialize the camera with a given viewport.
        public Camera(Viewport viewport)
        {
            _viewport = viewport;
            // Initialize the camera position (e.g., starting in the middle of the screen vertically).
            Position = new Vector2(0, 500);
        }

        // Moves the camera by a specified amount, keeping it clamped within world bounds.
        public void Move(Vector2 amount)
        {
            Position += amount; // Update the camera's position by the specified amount.
            Position = ClampPosition(Position); // Ensure the position stays within the valid bounds.
        }

        // Sets the bounds of the world to restrict the camera's movement.
        public void SetWorldBounds(Rectangle worldBounds)
        {
            _worldBounds = worldBounds;
        }

        // Returns the view matrix, which transforms world coordinates into screen coordinates.
        public Matrix GetViewMatrix()
        {
            // Create a translation matrix to move the world opposite to the camera's position.
            Matrix translationMatrix = Matrix.CreateTranslation(new Vector3(-Position.X, -Position.Y, 0));

            // Center the view matrix around the middle of the viewport.
            Matrix centerMatrix = Matrix.CreateTranslation(new Vector3(_viewport.Width / 2f, _viewport.Height / 2f, 0));

            // Combine the translation and centering matrices to produce the final view matrix.
            return translationMatrix * centerMatrix;
        }

        // Converts a screen position to a world position based on the camera's view matrix.
        public Vector2 ScreenToWorld(Vector2 screenPosition)
        {
            // Invert the view matrix to transform screen coordinates back to world coordinates.
            Matrix inverseViewMatrix = Matrix.Invert(GetViewMatrix());
            return Vector2.Transform(screenPosition, inverseViewMatrix);
        }

        // Ensures the camera's position stays within the bounds of the world.
        private Vector2 ClampPosition(Vector2 position)
        {
            // If no world bounds are set, don't clamp the position.
            if (_worldBounds == Rectangle.Empty)
                return position;

            // Calculate the half-width and half-height of the screen for proper clamping.
            float halfScreenWidth = _viewport.Width / 2f;
            float halfScreenHeight = _viewport.Height / 2f;

            // Determine the minimum and maximum allowed positions for the camera.
            float minX = _worldBounds.Left + halfScreenWidth;
            float maxX = _worldBounds.Right - halfScreenWidth;
            float minY = _worldBounds.Top + halfScreenHeight;
            float maxY = _worldBounds.Bottom - halfScreenHeight;

            // Clamp the camera's X and Y positions within these bounds.
            float clampedX = MathHelper.Clamp(position.X, minX, maxX);
            float clampedY = MathHelper.Clamp(position.Y, minY, maxY);

            return new Vector2(clampedX, clampedY);
        }
    }
}
