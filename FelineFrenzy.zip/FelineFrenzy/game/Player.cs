﻿using FelineFrenzy.Generics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;

namespace FelineFrenzy.Game
{
    // The Player class represents the player character and manages its state, movement, and interactions.
    internal class Player : Sprite
    {
        // Reference to the ContentManager for loading resources (e.g., textures).
        ContentManager content;

        // Constructor to initialize the player with its texture, position, color, opacity, and content manager.
        public Player(Texture2D texture, Vector2 position, Color colour, float opacity, ContentManager contentManager, int NumberOfTiles)
            : base(texture, position, colour, opacity)
        {
            rect = new Rectangle(0, 0, 108, 81);  // Initialize player rectangle dimensions.
            this.content = contentManager;         // Store reference to the content manager.
            this.numberOfTiles = NumberOfTiles;    // Initialize the number of tiles the player has.
        }

        // Number of tiles the player can place.
        public int numberOfTiles;

        // Player's horizontal and vertical velocity.
        float VelocityX = 0;
        float VelocityY = 0;

        // Index for the sprite animation and a counter for frame timing.
        int SpriteIndex = 0;
        int counter = 0;

        // Collision and movement-related flags.
        bool Collision = true;
        bool isOnGround = false;

        // Rotation and sprite effect (e.g., flipping the sprite horizontally).
        float Rotation = 0f;
        SpriteEffects CatEffect = SpriteEffects.None;

        // Updates the player's state, including movement, collision, and animation.
        public void UpdatePlayer(List<Tile> tiles)
        {
            KeyboardState kstate = Keyboard.GetState();  // Get current keyboard state.

            float gravity = 0.8f;          // Gravity strength affecting the player.
            float jumpStrength = -25;      // Strength of the jump.
            float acceleration = 0.5f;     // Player acceleration.
            float maxSpeed = 7;            // Maximum horizontal speed.
            float friction = 0.5f;         // Friction to slow the player down.

            // Handle left movement (A key).
            if (kstate.IsKeyDown(Keys.A))
            {
                // Apply left movement, accelerate, and flip sprite effect.
                VelocityX = Math.Max(VelocityX - acceleration, -maxSpeed); // Prevents player from going too fast left.
                CatEffect = SpriteEffects.FlipHorizontally;

                if (isOnGround == true)
                {
                    counter++;
                    if (counter > 8)
                    {
                        SpriteIndex++;
                        counter = 0;
                    }
                    if (SpriteIndex == 6)
                    {
                        SpriteIndex = 0; // Loop back to the beginning of the sprite animation.
                    }
                }
            }

            // Handle right movement (D key).
            if (kstate.IsKeyDown(Keys.D))
            {
                // Apply right movement, accelerate, and keep sprite effect as normal.
                VelocityX = Math.Min(VelocityX + acceleration, maxSpeed); // Prevents player from going too fast right.
                CatEffect = SpriteEffects.None;

                if (isOnGround == true)
                {
                    counter++;
                    if (counter > 8)
                    {
                        SpriteIndex++;
                        counter = 0;
                    }
                    if (SpriteIndex == 6)
                    {
                        SpriteIndex = 0; // Loop back to the beginning of the sprite animation.
                    }
                }
            }

            // Apply velocity to the player's position.
            rect.X += (int)VelocityX;

            // Apply friction when no horizontal movement.
            if (!kstate.IsKeyDown(Keys.A) && !kstate.IsKeyDown(Keys.D))
            {
                VelocityX *= friction;
            }

            // Handle collision with tiles.
            if (Collision == true)
            {
                foreach (Tile tile in tiles)
                {
                    if (rect.Intersects(tile.rect))
                    {
                        if (VelocityX < 0)
                        {
                            rect.X = tile.rect.Right; // Player collides from the left.
                        }
                        else if (VelocityX > 0)
                        {
                            rect.X = tile.rect.Left - rect.Width; // Player collides from the right.
                        }
                    }
                }
            }

            // Apply gravity and handle jumping.
            VelocityY += gravity;
            if (kstate.IsKeyDown(Keys.W) && isOnGround == true)
            {
                VelocityY = jumpStrength; // Apply jump force if player is on the ground.
                isOnGround = false;
            }

            // Apply vertical velocity.
            rect.Y += (int)VelocityY;

            // Handle vertical collisions with tiles.
            if (Collision == true)
            {
                foreach (Tile tile in tiles)
                {
                    if (rect.Intersects(tile.rect))
                    {
                        if (VelocityY > 0)
                        {
                            rect.Y = tile.rect.Top - rect.Height; // Collision from below (top of tile).
                            isOnGround = true;                   // Player lands on the tile.
                            VelocityY = 0;                        // Reset vertical velocity.
                        }
                        else if (VelocityY < 0)
                        {
                            rect.Y = tile.rect.Bottom; // Collision from above (bottom of tile).
                            VelocityY = 0;              // Reset vertical velocity.
                        }
                    }
                }
            }

            // Update player position to match rect.
            Position.Y = rect.Y;
            Position.X = rect.X;
        }

        // Allows the player to place and remove tiles based on mouse interactions.
        public void PlayerPlaceTile(MouseManager mouse, Rectangle mouseRect, List<Rectangle> cells, List<Tile> tiles, List<Tile> WorldTiles)
        {
            bool TogglePlaceTile = true;

            // Handle placing tiles if the mouse intersects valid cell positions.
            foreach (Rectangle cell in cells)
            {
                if (mouseRect.Intersects(cell) && TogglePlaceTile == true)
                {
                    if (mouseRect.Intersects(rect) || rect.Intersects(cell))
                    {
                        TogglePlaceTile = false; // Prevent placing tiles on top of the player.
                    }
                    else
                    {
                        TogglePlaceTile = true;  // Allow placing tiles if conditions are met.
                    }

                    if (mouse.MouseLeft && TogglePlaceTile)
                    {
                        tiles.Add(new Tile(content.Load<Texture2D>("GameSprites/SpriteSheetTiles"),
                                           new Vector2(cell.X, cell.Y),
                                           Color.LightGoldenrodYellow,
                                           1.0f,
                                           1));
                        numberOfTiles--; // Decrease the number of tiles the player has.
                    }
                }

                if (numberOfTiles == 0)
                {
                    break; // Stop placing tiles if the player has no tiles left.
                }
            }

            // Handle removing tiles using right mouse button.
            List<Tile> killTile = new List<Tile>();
            foreach (Tile tile in tiles)
            {
                if (mouseRect.Intersects(tile.rect))
                {
                    // Ensure the tile is not part of the world tiles before deleting.
                    foreach (Tile worldTile in WorldTiles)
                    {
                        if (mouseRect.Intersects(worldTile.rect))
                        {
                            TogglePlaceTile = false;
                            break;
                        }
                    }

                    if (TogglePlaceTile == false)
                    {
                        break; // If the tile is part of world tiles, don't delete.
                    }

                    if (mouse.MouseRight && TogglePlaceTile)
                    {
                        killTile.Add(tile); // Add the tile to be removed.
                        numberOfTiles++;     // Increase the number of tiles after removing one.
                    }

                    tile.colour = Color.LightGreen; // Highlight the tile when hovered.
                }
                else
                {
                    tile.colour = Color.LightGoldenrodYellow; // Reset tile color when not hovered.
                }
            }

            // Remove the tiles that were queued for deletion.
            tiles.RemoveAll(Tile => killTile.Contains(Tile));
        }

        // Reduces the player's lives and transitions to the previous scene.
        public void PlayerDeath(SceneManager SceneManager_)
        {
            SceneManager_.RemoveScene(); // Remove current scene (player death).
        }

        // Collides with yarn balls and triggers behavior like resetting position.
        public void CollideYarnBall(List<Yarnball> yarnballs)
        {
            foreach (Yarnball yarnball in yarnballs)
            {
                if (rect.Intersects(yarnball.rect))
                {
                    Position.X = 100; // Reset player position on yarnball collision.
                }
            }
        }

        // Draws the player using the current sprite frame and effects.
        public void Draw(SpriteBatch spriteBatch, Rectangle[] SpriteCatWalk)
        {
            spriteBatch.Draw(
                Texture,              // Draw the player texture.
                Position,              // Position to draw the player.
                SpriteCatWalk[SpriteIndex], // Draw the current sprite frame.
                Color.White,           // Color of the player.
                Rotation,              // Rotation angle.
                Vector2.Zero,          // Origin (center of sprite).
                1f,                    // Scale factor.
                CatEffect,             // Sprite effect (e.g., flipping).
                0f                     // Depth (drawing order).
            );
        }
    }
}
