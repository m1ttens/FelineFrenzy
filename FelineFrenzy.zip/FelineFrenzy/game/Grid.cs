﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;

namespace FelineFrenzy.Game
{
    // The Grid class represents a grid structure composed of rectangular cells.
    internal class Grid
    {
        // Width of the world in pixels
        public int WidthOfTheWorld;

        // Height of the world in pixels
        public int HeightOfTheWorld;

        // Number of rows in the grid
        public int Rows;

        // Number of columns in the grid.
        public int Columns;

        // Size of each cell (width and height are equal).
        public int CellSize;

        // List of rectangles representing the individual cells in the grid.
        public List<Rectangle> Cells;

        // Constructor to initialize the grid with the specified number of rows, columns, and cell size.
        // Parameters:
        // - rows: The number of rows in the grid.
        // - columns: The number of columns in the grid.
        // - cellsize: The width and height of each cell in the grid.
        public Grid(int rows, int columns, int cellsize)
        {
            // Assign the grid dimensions and cell size.
            this.Rows = rows;
            this.Columns = columns;
            this.CellSize = cellsize;

            WidthOfTheWorld = Rows * cellsize;
            HeightOfTheWorld = Columns * cellsize;

            // Initialize the list to store cells.
            Cells = new List<Rectangle>();

            // Populate the grid with cells, each represented as a rectangle.
            for (int y = 0; y < Rows; y++) // Iterate through each row.
            {
                for (int x = 0; x < Columns; x++) // Iterate through each column.
                {
                    // Create a rectangle for each cell and add it to the list.
                    Cells.Add(new Rectangle(x * CellSize, y * CellSize, cellsize, CellSize));
                }
            }
        }
    }
}
