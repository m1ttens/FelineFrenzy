﻿using FelineFrenzy.Generics;
using FelineFrenzy.Menu;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace FelineFrenzy.Game
{
    internal class Tile : Sprite
    {
        public int Index;


        public Tile(Texture2D texture, Vector2 position, Color colour, float opacity, int index) : base(texture, position, colour, opacity)
        {
            this.Index = index;
            rect = new Rectangle((int)position.X, (int)Position.Y, 128, 128);

        }
        public void Draw(SpriteBatch spriteBatch, Rectangle[] TextureRegions)
        {
            spriteBatch.Draw(Texture, Position, TextureRegions[Index], colour * opacity);
        }

    }
}
