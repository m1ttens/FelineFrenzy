﻿using FelineFrenzy.Generics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Diagnostics.Metrics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelineFrenzy.Game
{
    internal class Player : Sprite
    {
        ContentManager ContentManager;
        public int Lives = 10;


        public Player(Texture2D texture, Vector2 position, Color colour, float opacity, ContentManager contentManager) : base(texture, position, colour, opacity)
        {
            this.ContentManager = contentManager;
            load();
        }
        public void load() 
        { 
        
        
        
        }
        int SpriteIndex = 0;
        int counter = 0;
        float VelocityX = 0;
        float VelocityY = 0;

        bool isOnGround = false;
        SpriteEffects CatEffect = SpriteEffects.None;
        public void UpdatePlayer() 
        { 
            KeyboardState kstate = Keyboard.GetState();

            float gravity = 0.8f;
            float jumpStrength = -25;

            float acceleration = 0.5f;
            float maxSpeed = 7;
            float friction = 0.5f;

            if (kstate.IsKeyDown(Keys.A))
            {
                //Right Animation
                VelocityX = Math.Max(VelocityX - acceleration, -maxSpeed);
                CatEffect = SpriteEffects.FlipHorizontally;
                if (isOnGround == true)
                {
                    counter++;
                    if (counter > 8)
                    {
                        SpriteIndex++;

                        counter = 0;

                    }
                    if (SpriteIndex == 6)
                    {

                        SpriteIndex = 0;

                    }
                }
                if (kstate.IsKeyDown(Keys.D))
                {
                    //Left Animation
                    VelocityX = Math.Min(VelocityX + acceleration, maxSpeed);
                    CatEffect = SpriteEffects.None;
                    if (isOnGround == true)
                    {
                        counter++;
                        if (counter > 8)
                        {
                            SpriteIndex++;
                            counter = 0;

                        }
                        if (SpriteIndex == 6)
                        {
                            SpriteIndex = 0;
                        }
                    }
                }
                rect.X += (int)VelocityX;
                if (!kstate.IsKeyDown(Keys.A) || !kstate.IsKeyDown(Keys.D)) { VelocityX *= friction; }



            }


        }



    }
}
