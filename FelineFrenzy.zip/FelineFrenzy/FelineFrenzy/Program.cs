﻿
using var game = new FelineFrenzy.Game1();
game.Run();
