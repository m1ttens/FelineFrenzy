﻿using FelineFenzy1;
using FelineFrenzy1.Generics;
using FelineFrenzy1.Levels;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;

namespace FelineFrenzy1.Menu
{
    internal class MenuScene :IScene
    {
        private ContentManager ContentManager;
        private SceneManager SceneManager;
        private GraphicsDeviceManager Graphics;

        private MouseManager MouseManager;

        MouseState currentMouseState;
        MouseState previousMouseState;

        Vector2 MousePosition;
        Rectangle MouseRectangle;

        


        public MenuScene(ContentManager contentManager, SceneManager sceneManager, GraphicsDeviceManager graphics) 
        { 
            this.ContentManager = contentManager;
            this.SceneManager = sceneManager;
            this.Graphics = graphics;
        }

        Sprite BackGround;
        Sprite TitleScreen;

        Sprite ButtonPlay;
        Sprite ButtonExit;
      
        public void Load() 
        {

            

            BackGround = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/SkyBackground"), new Vector2(0, 0), Color.White, 1.0f);
            TitleScreen = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/Title"), new Vector2(293, 17), Color.White, 1.0f);

            ButtonPlay = new Sprite(ContentManager.Load <Texture2D>("MenuSprites/ButtonPlay"), new Vector2(706, 540), Color.White, 1.0f);
            ButtonExit = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/ButtonExit"), new Vector2(706, 771), Color.White, 1.0f);

            MouseManager = new MouseManager();

        }
        public void UpdateMouse() 
        {
 


        }
        public void Update(GameTime gameTime) 
        {




        }
        public void Draw(SpriteBatch spriteBatch) 
        {

            spriteBatch.Begin();
            BackGround.Draw(spriteBatch); //Layer 1 
            TitleScreen.Draw(spriteBatch);
            ButtonPlay.Draw(spriteBatch);
            ButtonExit.Draw(spriteBatch); //Layer 4



            spriteBatch.End();
        
        
        }

    }
}
