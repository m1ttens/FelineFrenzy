﻿using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelineFrenzy.Generics
{
    internal class MouseManager
    {
        MouseState currentMouseState;
        MouseState previousMouseState;

        public bool MouseLeft = false;
        public bool MouseRight = false;

        public bool MouseLeftHold = false;
        public bool MouseRightHold = false;

        public void UpdateMouse()
        {
            previousMouseState = currentMouseState;
            currentMouseState = Mouse.GetState();



            //Pressed Down
            if (currentMouseState.LeftButton == ButtonState.Pressed && previousMouseState.LeftButton == ButtonState.Released)
            {
                MouseLeft = true;


            }
            else { MouseLeft = false; }

            if (currentMouseState.RightButton == ButtonState.Pressed && previousMouseState.RightButton == ButtonState.Released)
            {
                MouseRight = true;


            }
            else { MouseRight = false; }


            //HoldDown 
            if (currentMouseState.LeftButton == ButtonState.Pressed)
            {
                MouseLeftHold = true;


            }
            else { MouseLeftHold = false; }
            if (currentMouseState.RightButton == ButtonState.Pressed)
            {
                MouseRightHold = true;


            }
            else { MouseRightHold = false; }



        }




    }
}
