﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
namespace FelineFrenzy.Generics
{
    internal class Sprite
    {
        public Texture2D Texture;
        public Vector2 Position;
        public Rectangle rect;
        public Color colour;
        public float opacity;

        public Sprite(Texture2D texture, Vector2 position, Color colour, float opacity)
        {
            this.Texture = texture;
            this.Position = position;
            this.colour = colour;
            this.opacity = opacity;
            rect = new((int)Position.X, (int)Position.Y, (int)Texture.Width, (int)Texture.Height);
        }
        public bool ButtonSpriteLeftUpdate(MouseManager mouseManager, Rectangle MouseRect, Rectangle SpriteRect)
        {
            if (MouseRect.Intersects(SpriteRect) && mouseManager.MouseLeft == true)
            {
                return true;
            }
            else return false;

        }
        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(Texture, Position, colour * opacity);

        }
    }
}
