﻿using Microsoft.Xna.Framework.Input;
using System;

namespace FelineFrenzy.Generics
{
    // The MouseManager class is responsible for managing mouse input states, such as button clicks and holds.
    internal class MouseManager
    {
        // Tracks the current and previous states of the mouse.
        MouseState currentMouseState;
        MouseState previousMouseState;

        // Flags to indicate if the left or right mouse button was clicked.
        public bool MouseLeft = false;
        public bool MouseRight = false;

        // Flags to indicate if the left or right mouse button is being held down.


        // Updates the mouse states and sets the flags accordingly.
        public void UpdateMouse()
        {
            // Store the previous state of the mouse.
            previousMouseState = currentMouseState;

            // Get the current state of the mouse.
            currentMouseState = Mouse.GetState();

            // Check if the left mouse button was just pressed (transition from Released to Pressed).
            if (currentMouseState.LeftButton == ButtonState.Pressed && previousMouseState.LeftButton == ButtonState.Released)
            {
                MouseLeft = true; // Left mouse button clicked.
            }
            else
            {
                MouseLeft = false; // Reset the flag if not clicked.
            }

            // Check if the right mouse button was just pressed (transition from Released to Pressed).
            if (currentMouseState.RightButton == ButtonState.Pressed && previousMouseState.RightButton == ButtonState.Released)
            {
                MouseRight = true; // Right mouse button clicked.
            }
            else
            {
                MouseRight = false; // Reset the flag if not clicked.
            }

       
        }
    }
}
