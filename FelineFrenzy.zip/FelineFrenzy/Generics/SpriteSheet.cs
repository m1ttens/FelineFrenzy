﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace FelineFrenzy.Generics
{
    // The SpriteSheet class handles dividing a texture atlas into individual sprite regions.
    internal class SpriteSheet
    {
        // The texture atlas containing all sprites.
        private Texture2D TextureAtlas;

        // An array of rectangles representing individual sprite regions within the texture atlas.
        public Rectangle[] TextureRegions;

        // Constructor that initializes the sprite sheet with a texture atlas and sprite dimensions.
        // Parameters:
        // - textureAtlas: The texture containing all the sprites.
        // - spriteWidth: The width of each individual sprite.
        // - spriteHeight: The height of each individual sprite.
        public SpriteSheet(Texture2D textureAtlas, int spriteWidth, int spriteHeight)
        {
            this.TextureAtlas = textureAtlas; // Assign the texture atlas.

            // Calculate the number of sprites along the X (width) and Y (height) axes.
            int numberSpritesX = textureAtlas.Width / spriteWidth;
            int numberSpritesY = textureAtlas.Height / spriteHeight;

            // Initialize the array to hold all sprite regions.
            TextureRegions = new Rectangle[numberSpritesX * numberSpritesY];

            // Loop through each row and column of the texture atlas to define sprite regions.
            for (int y = 0; y < numberSpritesY; y++) // Loop through rows.
            {
                for (int x = 0; x < numberSpritesX; x++) // Loop through columns.
                {
                    // Calculate the rectangle for each sprite region based on its position and dimensions.
                    TextureRegions[y * numberSpritesX + x] = new Rectangle(
                        x * spriteWidth,  // X-coordinate of the sprite.
                        y * spriteHeight, // Y-coordinate of the sprite.
                        spriteWidth,      // Width of the sprite.
                        spriteHeight      // Height of the sprite.
                    );
                }
            }
        }
    }
}
