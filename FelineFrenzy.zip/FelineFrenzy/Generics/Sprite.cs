﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;

namespace FelineFrenzy.Generics
{
    // The Sprite class represents a drawable game object with texture, position, color, and opacity.
    internal class Sprite
    {
        // Texture of the sprite (the image to be drawn).
        public Texture2D Texture;

        // Position of the sprite on the screen.
        public Vector2 Position;

        // Rectangle representing the dimensions of the sprite.
        public Rectangle rect;

        // Color tint to apply when drawing the sprite.
        public Color colour;

        // Opacity level of the sprite (0.0f - fully transparent, 1.0f - fully opaque).
        public float opacity;

        // Constructor to initialize the sprite with a texture, position, color, and opacity.
        public Sprite(Texture2D texture, Vector2 position, Color colour, float opacity)
        {
            this.Texture = texture; // Assign the texture.
            this.Position = position; // Set the position of the sprite.
            this.colour = colour; // Set the color tint.
            this.opacity = opacity; // Set the opacity.

            // Create a rectangle based on the sprite's position and texture dimensions.
            rect = new((int)Position.X, (int)Position.Y, (int)Texture.Width, (int)Texture.Height);
        }

        // Checks if the left mouse button interacts with the sprite.
        // Parameters:
        // - mouseManager: Manages mouse input states.
        // - MouseRect: The rectangle representing the current mouse position.
        // - SpriteRect: The rectangle representing the sprite's bounds.
        // Returns true if the mouse intersects the sprite and the left button is pressed.
        public bool ButtonSpriteLeftUpdate(MouseManager mouseManager, Rectangle MouseRect, Rectangle SpriteRect)
        {
            if (MouseRect.Intersects(SpriteRect) && mouseManager.MouseLeft == true)
            {
                return true; // Mouse clicked on the sprite.
            }
            else return false; // No interaction.
        }

        // Draws the sprite on the screen.
        // Parameters:
        // - spriteBatch: Used to batch and draw sprites efficiently.
        public virtual void Draw(SpriteBatch spriteBatch)
        {
            // Draw the sprite at its position with the specified color and opacity.
            spriteBatch.Draw(Texture, Position, colour * opacity);
        }
    }
}

