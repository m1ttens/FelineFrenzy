﻿using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;
using FelineFrenzy;
using FelineFrenzy.Game;
using FelineFrenzy.Generics;
using Microsoft.Xna.Framework.Input;

namespace FelineFrenzy.Levels
{
    internal class GameScene2 : IScene
    {
        // Fields
        private readonly ContentManager contentManager; // Manages content like textures, fonts, etc.
        private readonly SceneManager sceneManager;     // Manages game scenes
        private readonly GraphicsDeviceManager graphics; // Graphics manager for the game

        private SpriteFont font;          // Font for HUD display
        private Sprite FlagPole;          // Flag pole sprite

        private MouseState currentMouseState; // Current state of the mouse
        private Rectangle mouseRectangle;   // Rectangle representing the mouse position
        private Vector2 mouseScreenPosition; // Mouse position in screen coordinates
        private Vector2 mouseWorldPosition;  // Mouse position in world coordinates

        private List<Yarnball> yarnBalls;    // List of yarn balls
        private List<Tile> tileList;         // List of tiles
        private List<Tile> worldTiles;       // List of world tiles

        private Random random;               // Random number generator
        private double timeAccumulator;     // Accumulates elapsed time for periodic actions
        private const double TimerInterval = 1; // Interval between periodic actions (in seconds)
        private double WorldTimer = 60;     // Timer counting down from 60 seconds
        private int WorldTimerInt;           // Integer version of the timer for display

        private Grid grid;                   // Grid system for organizing tile positions
        private WorldGeneration worldGeneration; // Handles world generation based on data
        private SpriteSheet playerSpriteSheet; // Sprite sheet for player visuals
        private SpriteSheet tileSpriteSheet;   // Sprite sheet for tile visuals
        private Player player;               // The player character
        private Camera camera;               // Camera to view the game world
        private MouseManager mouseManager;  // Manages mouse input

        // Constructor


        public GameScene2(ContentManager contentManager, SceneManager sceneManager, GraphicsDeviceManager graphics)
        {
            this.contentManager = contentManager; // Initialize content manager
            this.sceneManager = sceneManager;     // Initialize scene manager
            this.graphics = graphics;             // Initialize graphics device manager
        }

        // Load assets and initialize game components
        public void Load()
        {
            random = new Random();               // Initialize random number generator
            worldTiles = new List<Tile>();      // Initialize list for world tiles
            tileList = new List<Tile>();         // Initialize list for regular tiles
            yarnBalls = new List<Yarnball>();    // Initialize list for yarn balls

            grid = new Grid(1000, 1000, 128);   // Initialize grid with dimensions and cell size
            camera = new Camera(graphics.GraphicsDevice.Viewport); // Initialize camera with screen bounds
            camera.SetWorldBounds(new Rectangle(0, 0, 100 * 128, 30 * 128)); // Set world boundaries

            mouseManager = new MouseManager();  // Initialize mouse manager

            // Load sprite sheets
            tileSpriteSheet = new SpriteSheet(contentManager.Load<Texture2D>("GameSprites/SpriteSheetTiles"), 128, 128);
            playerSpriteSheet = new SpriteSheet(contentManager.Load<Texture2D>("GameSprites/PlayerSprite"), 128, 82);

            // Initialize player
            player = new Player(contentManager.Load<Texture2D>("GameSprites/PlayerSprite"), new Vector2(400, 400), Color.White, 1.0f, contentManager, 20);

            // Initialize world generation based on CSV data
            worldGeneration = new WorldGeneration(tileList, contentManager, grid, 1, @"C:\\dev\\FelineFrenzy\\FelineFrenzy\\Content\\Data\\World1_Level2.csv");

            // Load font and flag pole sprite
            font = contentManager.Load<SpriteFont>("GeneralSprites/galleryFont");
            FlagPole = new Sprite(contentManager.Load<Texture2D>("GameSprites/Flagpole"), new Vector2(100 * 128 - 4 * 128, 2863 - 128 * 3 + 20), Color.White, 1.0f);

        }
        // Update game logic
        public void Update(GameTime gameTime) 
        {
            mouseManager.UpdateMouse();         // Update mouse state
            currentMouseState = Mouse.GetState(); // Get current mouse state

            mouseScreenPosition = new Vector2(currentMouseState.X, currentMouseState.Y); // Get mouse screen position
            mouseWorldPosition = camera.ScreenToWorld(mouseScreenPosition); // Convert to world position
            mouseRectangle = new Rectangle((int)mouseWorldPosition.X, (int)mouseWorldPosition.Y, 2, 2); // Create a small rectangle around the mouse

            player.UpdatePlayer(tileList);     // Update player logic related to tiles
            player.PlayerPlaceTile(mouseManager, mouseRectangle, grid.Cells, tileList, worldTiles); // Handle placing/removing tiles

            camera.Move(player.Position - camera.Position); // Move the camera to follow the player

            // Spawn yarn balls periodically
            timeAccumulator += gameTime.ElapsedGameTime.TotalSeconds; // Accumulate elapsed time
            WorldTimer -= gameTime.ElapsedGameTime.TotalSeconds;       // Decrease world timer
            WorldTimerInt = Convert.ToInt32(WorldTimer);               // Convert to integer for display

            if (timeAccumulator >= TimerInterval)                    // Check if it's time to spawn yarn balls
            {
                int randomXPosition = random.Next(player.rect.X, player.rect.X + 1000); // Random X position near the player
                yarnBalls.Add(new Yarnball(contentManager.Load<Texture2D>("GameSprites/YarnBall"), new Vector2(randomXPosition, 0), Color.White, 1, 10));
                timeAccumulator -= TimerInterval;                  // Reset accumulator
            }

            // Update all yarn balls
            foreach (Yarnball yarnBall in yarnBalls)
            {
                yarnBall.updateYarnBall(player, sceneManager, tileList); // Update each yarn ball
            }

            // Check if player has fallen out of bounds or touched the flag pole
            if (player.Position.Y > 4000)                          // Player death condition due to falling
            {
                player.PlayerDeath(sceneManager);                 // Handle player death
            }
            if (player.rect.Intersects(FlagPole.rect))            // Check if player reaches the flag pole
            {
                sceneManager.AddScene(new LevelMenu(contentManager, sceneManager, graphics)); // Transition to level menu
            }
            if (WorldTimerInt == 0)                               // Check if world timer has run out
            {
                player.PlayerDeath(sceneManager);                 // Handle player death
            }
        }
        // Draw the game scene
        public void Draw(SpriteBatch spriteBatch) 
        {
            spriteBatch.Begin(); // Begin sprite batch for drawing

            spriteBatch.End();   // End background drawing

            spriteBatch.Begin(transformMatrix: camera.GetViewMatrix()); // Begin drawing with camera view transformation
            foreach (Tile tile in tileList)                          // Draw all regular tiles
            {
                tile.Draw(spriteBatch, tileSpriteSheet.TextureRegions);
            }
            foreach (Tile tile in worldTiles)                        // Draw all world tiles
            {
                tile.Draw(spriteBatch, tileSpriteSheet.TextureRegions);
            }
            foreach (Yarnball yarnBall in yarnBalls)                 // Draw all yarn balls
            {
                yarnBall.Draw(spriteBatch);
            }
            player.Draw(spriteBatch, playerSpriteSheet.TextureRegions); // Draw the player
            FlagPole.Draw(spriteBatch);                            // Draw the flag pole
            spriteBatch.End();                                     // End drawing

            spriteBatch.Begin();                                    // Begin drawing HUD
            spriteBatch.DrawString(font, "Timer: " + WorldTimerInt.ToString(), new Vector2(0, 0), Color.White); // Draw world timer
            spriteBatch.DrawString(font, "TILES: " + player.numberOfTiles.ToString(), new Vector2(0, 100), Color.White); // Draw remaining tiles
            spriteBatch.End();                                       // End HUD drawing
        }

    }
}
