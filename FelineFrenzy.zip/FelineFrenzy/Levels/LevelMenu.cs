﻿using FelineFrenzy.Generics;
using FelineFrenzy1.Menu;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FelineFrenzy.Levels
{
    internal class LevelMenu : IScene
    {
        // Reference to ContentManager for loading game resources.
        private ContentManager ContentManager;
        // Reference to SceneManager for handling scene transitions.
        private SceneManager SceneManager;
        // Graphics device manager for accessing graphical properties.
        private GraphicsDeviceManager Graphics;
        // Font used for drawing text.
        private SpriteFont Font;
        // Custom mouse manager to handle mouse input.
        private MouseManager MouseManager;

        // Variables to track mouse state.
        MouseState currentMouseState;
        MouseState previousMouseState;

        // Current mouse position and rectangle for collision detection.
        Vector2 MousePosition;
        Rectangle MouseRectangle;

        // Constructor to initialize dependencies like content manager, scene manager, and graphics device.
        public LevelMenu(ContentManager contentManager, SceneManager sceneManager, GraphicsDeviceManager graphics)
        {
            this.ContentManager = contentManager;
            this.SceneManager = sceneManager;
            this.Graphics = graphics;
        }

        // Background sprite for the level menu.
        Sprite SkyBackground;
        // Buttons for navigating to different game scenes.
        Sprite Button1;
        Sprite Button2;
        Sprite Button3;
        Sprite Button4;
        Sprite Button5;
        Sprite ExitButton;

        // Load assets, such as textures and fonts, and initialize UI elements.
        public void Load()
        {
            Font = ContentManager.Load<SpriteFont>("GeneralSprites/galleryFont");  // Load font for UI.

            // Load and initialize background sprite.
            SkyBackground = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/SkyBackground"), new Vector2(0, 0), Color.White, 1.0f);

            MouseManager = new MouseManager();  // Initialize the mouse manager.

            // Load button sprites and their positions.
            Button1 = new Sprite(ContentManager.Load<Texture2D>("LevelMenuSprites/Button1"), new Vector2(117, 278), Color.White, 1.0f);
            Button2 = new Sprite(ContentManager.Load<Texture2D>("LevelMenuSprites/Button2"), new Vector2(469, 278), Color.White, 1.0f);
            Button3 = new Sprite(ContentManager.Load<Texture2D>("LevelMenuSprites/Button3"), new Vector2(821, 278), Color.White, 1.0f);
            Button4 = new Sprite(ContentManager.Load<Texture2D>("LevelMenuSprites/Button4"), new Vector2(1173, 278), Color.White, 1.0f);
            Button5 = new Sprite(ContentManager.Load<Texture2D>("LevelMenuSprites/Button5"), new Vector2(1525, 278), Color.White, 1.0f);
            ExitButton = new Sprite(ContentManager.Load<Texture2D>("MenuSprites/ButtonExit"), new Vector2(0, 0), Color.White, 1.0f);
        }

        // Updates the mouse state and its position.
        public void UpdateMouse()
        {
            MouseManager.UpdateMouse();  // Update mouse manager.

            // Store current and previous mouse states.
            previousMouseState = currentMouseState;
            currentMouseState = Mouse.GetState();

            MousePosition = new Vector2(currentMouseState.X, currentMouseState.Y);  // Get current mouse position.
            MouseRectangle = new Rectangle((int)currentMouseState.X, (int)currentMouseState.Y, 1, 1);  // Define a small rectangle representing the mouse pointer.
        }

        private float countdown = 5f;  // Countdown timer to delay mouse input update.

        // Update logic for the level menu.
        public void Update(GameTime gameTime)
        {
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;  // Calculate elapsed time since last frame.

            // Check if enough time has passed before updating mouse input.
            if (deltaTime >= 5)
            {
                UpdateMouse();  // Update mouse state.
            }

            // Update mouse state again to ensure current status is captured.
            UpdateMouse();

            // Check if the left mouse button is clicked on each button.
            if (Button1.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, Button1.rect) == true)
            {
                SceneManager.AddScene(new GameScene1(ContentManager, SceneManager, Graphics));  // Switch to GameScene1.
            }
            if (Button2.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, Button2.rect) == true)
            {
                SceneManager.AddScene(new GameScene2(ContentManager, SceneManager, Graphics));  // Switch to GameScene2.
            }
            if (Button3.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, Button3.rect) == true)
            {
                SceneManager.AddScene(new GameScene3(ContentManager, SceneManager, Graphics));  // Switch to GameScene3.
            }
            if (Button4.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, Button4.rect) == true)
            {
                SceneManager.AddScene(new GameScene4(ContentManager, SceneManager, Graphics));  // Switch to GameScene4.
            }
            if (Button5.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, Button5.rect) == true)
            {
                SceneManager.AddScene(new GameScene5(ContentManager, SceneManager, Graphics));  // Switch to GameScene5.
            }
            if (ExitButton.ButtonSpriteLeftUpdate(MouseManager, MouseRectangle, ExitButton.rect) == true)
            {
                SceneManager.AddScene(new MenuScene(ContentManager, SceneManager, Graphics));  // Switch back to menu page.
            }
        }

        // Draw all the UI elements to the screen.
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();  // Begin sprite batch drawing.

            SkyBackground.Draw(spriteBatch);  // Draw the background.
            Button1.Draw(spriteBatch);        // Draw button 1.
            Button2.Draw(spriteBatch);        // Draw button 2.
            Button3.Draw(spriteBatch);        // Draw button 3.
            Button4.Draw(spriteBatch);        // Draw button 4.
            Button5.Draw(spriteBatch);        // Draw button 5.
            ExitButton.Draw(spriteBatch);     //Draw Exit button

            spriteBatch.End();  // End sprite batch drawing.
        }
    }
}
